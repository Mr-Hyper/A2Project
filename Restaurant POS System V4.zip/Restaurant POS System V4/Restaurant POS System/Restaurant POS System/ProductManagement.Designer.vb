﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProductManagement
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ProductManagement))
        Me.BtnBack = New System.Windows.Forms.Button()
        Me.BtnWater = New System.Windows.Forms.Button()
        Me.BtnSoftDrink = New System.Windows.Forms.Button()
        Me.BtnWine = New System.Windows.Forms.Button()
        Me.BtnCider = New System.Windows.Forms.Button()
        Me.BtnBeer = New System.Windows.Forms.Button()
        Me.BtnLager = New System.Windows.Forms.Button()
        Me.BtnSetMeal = New System.Windows.Forms.Button()
        Me.BtnEngDish = New System.Windows.Forms.Button()
        Me.BtnNan = New System.Windows.Forms.Button()
        Me.BtnRice = New System.Windows.Forms.Button()
        Me.BtnVegSideDish = New System.Windows.Forms.Button()
        Me.BtnBiryDish = New System.Windows.Forms.Button()
        Me.BtnVegMainDish = New System.Windows.Forms.Button()
        Me.BtnBaltDIsh = New System.Windows.Forms.Button()
        Me.BtnFishDish = New System.Windows.Forms.Button()
        Me.BtnSpecMildDish = New System.Windows.Forms.Button()
        Me.BtnAllTimeFav = New System.Windows.Forms.Button()
        Me.BtnHousSpec = New System.Windows.Forms.Button()
        Me.BtnTandDish = New System.Windows.Forms.Button()
        Me.BtnStarters = New System.Windows.Forms.Button()
        Me.GrpBoxDish = New System.Windows.Forms.GroupBox()
        Me.GrpBoxDrink = New System.Windows.Forms.GroupBox()
        Me.DataGridViewPrdctMng = New System.Windows.Forms.DataGridView()
        Me.LblItemCount = New System.Windows.Forms.Label()
        CType(Me.DataGridViewPrdctMng, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BtnBack
        '
        Me.BtnBack.Location = New System.Drawing.Point(13, 13)
        Me.BtnBack.Name = "BtnBack"
        Me.BtnBack.Size = New System.Drawing.Size(75, 23)
        Me.BtnBack.TabIndex = 0
        Me.BtnBack.Text = "Back"
        Me.BtnBack.UseVisualStyleBackColor = True
        '
        'BtnWater
        '
        Me.BtnWater.Location = New System.Drawing.Point(196, 320)
        Me.BtnWater.Name = "BtnWater"
        Me.BtnWater.Size = New System.Drawing.Size(69, 31)
        Me.BtnWater.TabIndex = 48
        Me.BtnWater.Text = "Water"
        Me.BtnWater.UseVisualStyleBackColor = True
        '
        'BtnSoftDrink
        '
        Me.BtnSoftDrink.Location = New System.Drawing.Point(196, 283)
        Me.BtnSoftDrink.Name = "BtnSoftDrink"
        Me.BtnSoftDrink.Size = New System.Drawing.Size(69, 31)
        Me.BtnSoftDrink.TabIndex = 47
        Me.BtnSoftDrink.Text = "Soft Drinks"
        Me.BtnSoftDrink.UseVisualStyleBackColor = True
        '
        'BtnWine
        '
        Me.BtnWine.Location = New System.Drawing.Point(196, 246)
        Me.BtnWine.Name = "BtnWine"
        Me.BtnWine.Size = New System.Drawing.Size(69, 31)
        Me.BtnWine.TabIndex = 46
        Me.BtnWine.Text = "Wines"
        Me.BtnWine.UseVisualStyleBackColor = True
        '
        'BtnCider
        '
        Me.BtnCider.Location = New System.Drawing.Point(196, 209)
        Me.BtnCider.Name = "BtnCider"
        Me.BtnCider.Size = New System.Drawing.Size(69, 31)
        Me.BtnCider.TabIndex = 45
        Me.BtnCider.Text = "Ciders"
        Me.BtnCider.UseVisualStyleBackColor = True
        '
        'BtnBeer
        '
        Me.BtnBeer.Location = New System.Drawing.Point(196, 172)
        Me.BtnBeer.Name = "BtnBeer"
        Me.BtnBeer.Size = New System.Drawing.Size(69, 31)
        Me.BtnBeer.TabIndex = 44
        Me.BtnBeer.Text = "Beers"
        Me.BtnBeer.UseVisualStyleBackColor = True
        '
        'BtnLager
        '
        Me.BtnLager.Location = New System.Drawing.Point(196, 135)
        Me.BtnLager.Name = "BtnLager"
        Me.BtnLager.Size = New System.Drawing.Size(69, 31)
        Me.BtnLager.TabIndex = 43
        Me.BtnLager.Text = "Lagers"
        Me.BtnLager.UseVisualStyleBackColor = True
        '
        'BtnSetMeal
        '
        Me.BtnSetMeal.Location = New System.Drawing.Point(101, 360)
        Me.BtnSetMeal.Name = "BtnSetMeal"
        Me.BtnSetMeal.Size = New System.Drawing.Size(69, 40)
        Me.BtnSetMeal.TabIndex = 42
        Me.BtnSetMeal.Text = "Set Meals"
        Me.BtnSetMeal.UseVisualStyleBackColor = True
        '
        'BtnEngDish
        '
        Me.BtnEngDish.Location = New System.Drawing.Point(26, 360)
        Me.BtnEngDish.Name = "BtnEngDish"
        Me.BtnEngDish.Size = New System.Drawing.Size(69, 40)
        Me.BtnEngDish.TabIndex = 41
        Me.BtnEngDish.Text = "English Dishes"
        Me.BtnEngDish.UseVisualStyleBackColor = True
        '
        'BtnNan
        '
        Me.BtnNan.Location = New System.Drawing.Point(101, 314)
        Me.BtnNan.Name = "BtnNan"
        Me.BtnNan.Size = New System.Drawing.Size(69, 40)
        Me.BtnNan.TabIndex = 40
        Me.BtnNan.Text = "Nan"
        Me.BtnNan.UseVisualStyleBackColor = True
        '
        'BtnRice
        '
        Me.BtnRice.Location = New System.Drawing.Point(26, 314)
        Me.BtnRice.Name = "BtnRice"
        Me.BtnRice.Size = New System.Drawing.Size(69, 40)
        Me.BtnRice.TabIndex = 39
        Me.BtnRice.Text = "Rice"
        Me.BtnRice.UseVisualStyleBackColor = True
        '
        'BtnVegSideDish
        '
        Me.BtnVegSideDish.Location = New System.Drawing.Point(101, 268)
        Me.BtnVegSideDish.Name = "BtnVegSideDish"
        Me.BtnVegSideDish.Size = New System.Drawing.Size(69, 40)
        Me.BtnVegSideDish.TabIndex = 38
        Me.BtnVegSideDish.Text = "Veg Side Dishes"
        Me.BtnVegSideDish.UseVisualStyleBackColor = True
        '
        'BtnBiryDish
        '
        Me.BtnBiryDish.Location = New System.Drawing.Point(26, 268)
        Me.BtnBiryDish.Name = "BtnBiryDish"
        Me.BtnBiryDish.Size = New System.Drawing.Size(69, 40)
        Me.BtnBiryDish.TabIndex = 37
        Me.BtnBiryDish.Text = "Biryani Dishes"
        Me.BtnBiryDish.UseVisualStyleBackColor = True
        '
        'BtnVegMainDish
        '
        Me.BtnVegMainDish.Location = New System.Drawing.Point(101, 222)
        Me.BtnVegMainDish.Name = "BtnVegMainDish"
        Me.BtnVegMainDish.Size = New System.Drawing.Size(69, 40)
        Me.BtnVegMainDish.TabIndex = 36
        Me.BtnVegMainDish.Text = "Veg Main Dishes"
        Me.BtnVegMainDish.UseVisualStyleBackColor = True
        '
        'BtnBaltDIsh
        '
        Me.BtnBaltDIsh.Location = New System.Drawing.Point(26, 222)
        Me.BtnBaltDIsh.Name = "BtnBaltDIsh"
        Me.BtnBaltDIsh.Size = New System.Drawing.Size(69, 40)
        Me.BtnBaltDIsh.TabIndex = 35
        Me.BtnBaltDIsh.Text = "Balti Dishes"
        Me.BtnBaltDIsh.UseVisualStyleBackColor = True
        '
        'BtnFishDish
        '
        Me.BtnFishDish.Location = New System.Drawing.Point(101, 176)
        Me.BtnFishDish.Name = "BtnFishDish"
        Me.BtnFishDish.Size = New System.Drawing.Size(69, 40)
        Me.BtnFishDish.TabIndex = 34
        Me.BtnFishDish.Text = "Fish Dishes"
        Me.BtnFishDish.UseVisualStyleBackColor = True
        '
        'BtnSpecMildDish
        '
        Me.BtnSpecMildDish.Location = New System.Drawing.Point(26, 176)
        Me.BtnSpecMildDish.Name = "BtnSpecMildDish"
        Me.BtnSpecMildDish.Size = New System.Drawing.Size(69, 40)
        Me.BtnSpecMildDish.TabIndex = 33
        Me.BtnSpecMildDish.Text = "Special Mild Dishes"
        Me.BtnSpecMildDish.UseVisualStyleBackColor = True
        '
        'BtnAllTimeFav
        '
        Me.BtnAllTimeFav.Location = New System.Drawing.Point(101, 130)
        Me.BtnAllTimeFav.Name = "BtnAllTimeFav"
        Me.BtnAllTimeFav.Size = New System.Drawing.Size(69, 40)
        Me.BtnAllTimeFav.TabIndex = 32
        Me.BtnAllTimeFav.Text = "All Time Favourites"
        Me.BtnAllTimeFav.UseVisualStyleBackColor = True
        '
        'BtnHousSpec
        '
        Me.BtnHousSpec.Location = New System.Drawing.Point(26, 130)
        Me.BtnHousSpec.Name = "BtnHousSpec"
        Me.BtnHousSpec.Size = New System.Drawing.Size(69, 40)
        Me.BtnHousSpec.TabIndex = 31
        Me.BtnHousSpec.Text = "House Specialities"
        Me.BtnHousSpec.UseVisualStyleBackColor = True
        '
        'BtnTandDish
        '
        Me.BtnTandDish.Location = New System.Drawing.Point(101, 84)
        Me.BtnTandDish.Name = "BtnTandDish"
        Me.BtnTandDish.Size = New System.Drawing.Size(69, 40)
        Me.BtnTandDish.TabIndex = 30
        Me.BtnTandDish.Text = "Tandoori Dishes"
        Me.BtnTandDish.UseVisualStyleBackColor = True
        '
        'BtnStarters
        '
        Me.BtnStarters.Location = New System.Drawing.Point(26, 84)
        Me.BtnStarters.Name = "BtnStarters"
        Me.BtnStarters.Size = New System.Drawing.Size(69, 40)
        Me.BtnStarters.TabIndex = 29
        Me.BtnStarters.Text = "Starters"
        Me.BtnStarters.UseVisualStyleBackColor = True
        '
        'GrpBoxDish
        '
        Me.GrpBoxDish.Location = New System.Drawing.Point(16, 68)
        Me.GrpBoxDish.Name = "GrpBoxDish"
        Me.GrpBoxDish.Size = New System.Drawing.Size(163, 342)
        Me.GrpBoxDish.TabIndex = 49
        Me.GrpBoxDish.TabStop = False
        Me.GrpBoxDish.Text = "Dishes"
        '
        'GrpBoxDrink
        '
        Me.GrpBoxDrink.Location = New System.Drawing.Point(185, 117)
        Me.GrpBoxDrink.Name = "GrpBoxDrink"
        Me.GrpBoxDrink.Size = New System.Drawing.Size(92, 245)
        Me.GrpBoxDrink.TabIndex = 50
        Me.GrpBoxDrink.TabStop = False
        Me.GrpBoxDrink.Text = "Drinks"
        '
        'DataGridViewPrdctMng
        '
        Me.DataGridViewPrdctMng.AllowUserToAddRows = False
        Me.DataGridViewPrdctMng.AllowUserToDeleteRows = False
        Me.DataGridViewPrdctMng.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridViewPrdctMng.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewPrdctMng.Location = New System.Drawing.Point(294, 37)
        Me.DataGridViewPrdctMng.MultiSelect = False
        Me.DataGridViewPrdctMng.Name = "DataGridViewPrdctMng"
        Me.DataGridViewPrdctMng.ReadOnly = True
        Me.DataGridViewPrdctMng.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridViewPrdctMng.Size = New System.Drawing.Size(494, 401)
        Me.DataGridViewPrdctMng.TabIndex = 51
        '
        'LblItemCount
        '
        Me.LblItemCount.AutoSize = True
        Me.LblItemCount.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblItemCount.Location = New System.Drawing.Point(469, 9)
        Me.LblItemCount.Name = "LblItemCount"
        Me.LblItemCount.Size = New System.Drawing.Size(152, 25)
        Me.LblItemCount.TabIndex = 52
        Me.LblItemCount.Text = "Item Count: 0"
        '
        'ProductManagement
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.LblItemCount)
        Me.Controls.Add(Me.DataGridViewPrdctMng)
        Me.Controls.Add(Me.BtnWater)
        Me.Controls.Add(Me.BtnSoftDrink)
        Me.Controls.Add(Me.BtnWine)
        Me.Controls.Add(Me.BtnCider)
        Me.Controls.Add(Me.BtnBeer)
        Me.Controls.Add(Me.BtnLager)
        Me.Controls.Add(Me.BtnSetMeal)
        Me.Controls.Add(Me.BtnEngDish)
        Me.Controls.Add(Me.BtnNan)
        Me.Controls.Add(Me.BtnRice)
        Me.Controls.Add(Me.BtnVegSideDish)
        Me.Controls.Add(Me.BtnBiryDish)
        Me.Controls.Add(Me.BtnVegMainDish)
        Me.Controls.Add(Me.BtnBaltDIsh)
        Me.Controls.Add(Me.BtnFishDish)
        Me.Controls.Add(Me.BtnSpecMildDish)
        Me.Controls.Add(Me.BtnAllTimeFav)
        Me.Controls.Add(Me.BtnHousSpec)
        Me.Controls.Add(Me.BtnTandDish)
        Me.Controls.Add(Me.BtnStarters)
        Me.Controls.Add(Me.GrpBoxDish)
        Me.Controls.Add(Me.GrpBoxDrink)
        Me.Controls.Add(Me.BtnBack)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "ProductManagement"
        Me.Text = "Product Management"
        CType(Me.DataGridViewPrdctMng, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BtnBack As Button
    Friend WithEvents BtnWater As Button
    Friend WithEvents BtnSoftDrink As Button
    Friend WithEvents BtnWine As Button
    Friend WithEvents BtnCider As Button
    Friend WithEvents BtnBeer As Button
    Friend WithEvents BtnLager As Button
    Friend WithEvents BtnSetMeal As Button
    Friend WithEvents BtnEngDish As Button
    Friend WithEvents BtnNan As Button
    Friend WithEvents BtnRice As Button
    Friend WithEvents BtnVegSideDish As Button
    Friend WithEvents BtnBiryDish As Button
    Friend WithEvents BtnVegMainDish As Button
    Friend WithEvents BtnBaltDIsh As Button
    Friend WithEvents BtnFishDish As Button
    Friend WithEvents BtnSpecMildDish As Button
    Friend WithEvents BtnAllTimeFav As Button
    Friend WithEvents BtnHousSpec As Button
    Friend WithEvents BtnTandDish As Button
    Friend WithEvents BtnStarters As Button
    Friend WithEvents GrpBoxDish As GroupBox
    Friend WithEvents GrpBoxDrink As GroupBox
    Friend WithEvents DataGridViewPrdctMng As DataGridView
    Friend WithEvents LblItemCount As Label
End Class
