﻿Imports System.Data.OleDb
Public Class ProductManagement
    Dim con1 As New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0;Data Source=Restaurant Product Database Connect.mdb")
    Dim ItemCount As Integer = 0

    Private Sub BtnBack_Click(sender As Object, e As EventArgs) Handles BtnBack.Click

        Me.Close()

    End Sub

    Private Sub BtnStarters_Click(sender As Object, e As EventArgs) Handles BtnStarters.Click
        Dim sql As String

        sql = "SELECT * FROM Starters"

        Dim adapter As New OleDbDataAdapter(sql, con1)
        Dim dt As New DataTable("Starters")
        adapter.Fill(dt)
        DataGridViewPrdctMng.DataSource = dt

        Dim sql1 = "SELECT * FROM Starters"
        Dim adapter1 As New OleDbDataAdapter(sql1, con1)
        Dim cmd1 As New OleDbCommand(sql1, con1)
        con1.Open()
        Dim myreader As OleDbDataReader = cmd1.ExecuteReader
        myreader.Read()

        con1.Close()

        ItemCount = DataGridViewPrdctMng.Rows.Count
        LblItemCount.Text = "Item Count: " & ItemCount

    End Sub

    Private Sub BtnTandDish_Click(sender As Object, e As EventArgs) Handles BtnTandDish.Click
        Dim sql As String

        sql = "SELECT * FROM TandooriDishes"

        Dim adapter As New OleDbDataAdapter(sql, con1)
        Dim dt As New DataTable("TandooriDishes")
        adapter.Fill(dt)
        DataGridViewPrdctMng.DataSource = dt

        Dim sql1 = "SELECT * FROM TandooriDishes"
        Dim adapter1 As New OleDbDataAdapter(sql1, con1)
        Dim cmd1 As New OleDbCommand(sql1, con1)
        con1.Open()
        Dim myreader As OleDbDataReader = cmd1.ExecuteReader
        myreader.Read()

        con1.Close()

        ItemCount = DataGridViewPrdctMng.Rows.Count
        LblItemCount.Text = "Item Count: " & ItemCount

    End Sub

    Private Sub BtnRice_Click(sender As Object, e As EventArgs) Handles BtnRice.Click
        Dim sql As String

        sql = "SELECT * FROM Rice"

        Dim adapter As New OleDbDataAdapter(sql, con1)
        Dim dt As New DataTable("Rice")
        adapter.Fill(dt)
        DataGridViewPrdctMng.DataSource = dt

        Dim sql1 = "SELECT * FROM Rice"
        Dim adapter1 As New OleDbDataAdapter(sql1, con1)
        Dim cmd1 As New OleDbCommand(sql1, con1)
        con1.Open()
        Dim myreader As OleDbDataReader = cmd1.ExecuteReader
        myreader.Read()

        con1.Close()

        ItemCount = DataGridViewPrdctMng.Rows.Count
        LblItemCount.Text = "Item Count: " & ItemCount

    End Sub

    Private Sub BtnNan_Click(sender As Object, e As EventArgs) Handles BtnNan.Click
        Dim sql As String

        sql = "SELECT * FROM Nan"

        Dim adapter As New OleDbDataAdapter(sql, con1)
        Dim dt As New DataTable("Nan")
        adapter.Fill(dt)
        DataGridViewPrdctMng.DataSource = dt

        Dim sql1 = "SELECT * FROM Nan"
        Dim adapter1 As New OleDbDataAdapter(sql1, con1)
        Dim cmd1 As New OleDbCommand(sql1, con1)
        con1.Open()
        Dim myreader As OleDbDataReader = cmd1.ExecuteReader
        myreader.Read()

        con1.Close()

        ItemCount = DataGridViewPrdctMng.Rows.Count
        LblItemCount.Text = "Item Count: " & ItemCount

    End Sub

    Private Sub BtnHousSpec_Click(sender As Object, e As EventArgs) Handles BtnHousSpec.Click
        Dim sql As String

        sql = "SELECT * FROM HouseSpecialities"

        Dim adapter As New OleDbDataAdapter(sql, con1)
        Dim dt As New DataTable("HouseSpecialities")
        adapter.Fill(dt)
        DataGridViewPrdctMng.DataSource = dt

        Dim sql1 = "SELECT * FROM HouseSpecialities"
        Dim adapter1 As New OleDbDataAdapter(sql1, con1)
        Dim cmd1 As New OleDbCommand(sql1, con1)
        con1.Open()
        Dim myreader As OleDbDataReader = cmd1.ExecuteReader
        myreader.Read()

        con1.Close()

        ItemCount = DataGridViewPrdctMng.Rows.Count
        LblItemCount.Text = "Item Count: " & ItemCount

    End Sub

    Private Sub BtnAllTimeFav_Click(sender As Object, e As EventArgs) Handles BtnAllTimeFav.Click
        Dim sql As String

        sql = "SELECT * FROM AllTimeFavourites"

        Dim adapter As New OleDbDataAdapter(sql, con1)
        Dim dt As New DataTable("AllTimeFavourites")
        adapter.Fill(dt)
        DataGridViewPrdctMng.DataSource = dt

        Dim sql1 = "SELECT * FROM AllTimeFavourites"
        Dim adapter1 As New OleDbDataAdapter(sql1, con1)
        Dim cmd1 As New OleDbCommand(sql1, con1)
        con1.Open()
        Dim myreader As OleDbDataReader = cmd1.ExecuteReader
        myreader.Read()

        con1.Close()

        ItemCount = DataGridViewPrdctMng.Rows.Count
        LblItemCount.Text = "Item Count: " & ItemCount

    End Sub

    Private Sub BtnSpecMildDish_Click(sender As Object, e As EventArgs) Handles BtnSpecMildDish.Click
        Dim sql As String

        sql = "SELECT * FROM SpecialMildDishes"

        Dim adapter As New OleDbDataAdapter(sql, con1)
        Dim dt As New DataTable("SpecialMildDishes")
        adapter.Fill(dt)
        DataGridViewPrdctMng.DataSource = dt

        Dim sql1 = "SELECT * FROM SpecialMildDishes"
        Dim adapter1 As New OleDbDataAdapter(sql1, con1)
        Dim cmd1 As New OleDbCommand(sql1, con1)
        con1.Open()
        Dim myreader As OleDbDataReader = cmd1.ExecuteReader
        myreader.Read()

        con1.Close()

        ItemCount = DataGridViewPrdctMng.Rows.Count
        LblItemCount.Text = "Item Count: " & ItemCount

    End Sub

    Private Sub BtnFishDish_Click(sender As Object, e As EventArgs) Handles BtnFishDish.Click
        Dim sql As String

        sql = "SELECT * FROM FishDishes"

        Dim adapter As New OleDbDataAdapter(sql, con1)
        Dim dt As New DataTable("FishDishes")
        adapter.Fill(dt)
        DataGridViewPrdctMng.DataSource = dt

        Dim sql1 = "SELECT * FROM FishDishes"
        Dim adapter1 As New OleDbDataAdapter(sql1, con1)
        Dim cmd1 As New OleDbCommand(sql1, con1)
        con1.Open()
        Dim myreader As OleDbDataReader = cmd1.ExecuteReader
        myreader.Read()

        con1.Close()

        ItemCount = DataGridViewPrdctMng.Rows.Count
        LblItemCount.Text = "Item Count: " & ItemCount

    End Sub

    Private Sub BtnBaltDIsh_Click(sender As Object, e As EventArgs) Handles BtnBaltDIsh.Click
        Dim sql As String

        sql = "SELECT * FROM BaltiDishes"

        Dim adapter As New OleDbDataAdapter(sql, con1)
        Dim dt As New DataTable("BaltiDishes")
        adapter.Fill(dt)
        DataGridViewPrdctMng.DataSource = dt

        Dim sql1 = "SELECT * FROM BaltiDishes"
        Dim adapter1 As New OleDbDataAdapter(sql1, con1)
        Dim cmd1 As New OleDbCommand(sql1, con1)
        con1.Open()
        Dim myreader As OleDbDataReader = cmd1.ExecuteReader
        myreader.Read()

        con1.Close()

        ItemCount = DataGridViewPrdctMng.Rows.Count
        LblItemCount.Text = "Item Count: " & ItemCount

    End Sub

    Private Sub BtnVegMainDish_Click(sender As Object, e As EventArgs) Handles BtnVegMainDish.Click
        Dim sql As String

        sql = "SELECT * FROM VegetableMainDishes"

        Dim adapter As New OleDbDataAdapter(sql, con1)
        Dim dt As New DataTable("VegetableMainDishes")
        adapter.Fill(dt)
        DataGridViewPrdctMng.DataSource = dt

        Dim sql1 = "SELECT * FROM VegetableMainDishes"
        Dim adapter1 As New OleDbDataAdapter(sql1, con1)
        Dim cmd1 As New OleDbCommand(sql1, con1)
        con1.Open()
        Dim myreader As OleDbDataReader = cmd1.ExecuteReader
        myreader.Read()

        con1.Close()

        ItemCount = DataGridViewPrdctMng.Rows.Count
        LblItemCount.Text = "Item Count: " & ItemCount

    End Sub

    Private Sub BtnBiryDish_Click(sender As Object, e As EventArgs) Handles BtnBiryDish.Click
        Dim sql As String

        sql = "SELECT * FROM BiryaniDishes"

        Dim adapter As New OleDbDataAdapter(sql, con1)
        Dim dt As New DataTable("BiryaniDishes")
        adapter.Fill(dt)
        DataGridViewPrdctMng.DataSource = dt

        Dim sql1 = "SELECT * FROM BiryaniDishes"
        Dim adapter1 As New OleDbDataAdapter(sql1, con1)
        Dim cmd1 As New OleDbCommand(sql1, con1)
        con1.Open()
        Dim myreader As OleDbDataReader = cmd1.ExecuteReader
        myreader.Read()

        con1.Close()

        ItemCount = DataGridViewPrdctMng.Rows.Count
        LblItemCount.Text = "Item Count: " & ItemCount

    End Sub

    Private Sub BtnVegSideDish_Click(sender As Object, e As EventArgs) Handles BtnVegSideDish.Click
        Dim sql As String

        sql = "SELECT * FROM VegetableSideDishes"

        Dim adapter As New OleDbDataAdapter(sql, con1)
        Dim dt As New DataTable("VegetableSideDishes")
        adapter.Fill(dt)
        DataGridViewPrdctMng.DataSource = dt

        Dim sql1 = "SELECT * FROM VegetableSideDishes"
        Dim adapter1 As New OleDbDataAdapter(sql1, con1)
        Dim cmd1 As New OleDbCommand(sql1, con1)
        con1.Open()
        Dim myreader As OleDbDataReader = cmd1.ExecuteReader
        myreader.Read()

        con1.Close()

        ItemCount = DataGridViewPrdctMng.Rows.Count
        LblItemCount.Text = "Item Count: " & ItemCount

    End Sub

    Private Sub BtnEngDish_Click(sender As Object, e As EventArgs) Handles BtnEngDish.Click
        Dim sql As String

        sql = "SELECT * FROM EnglishDishes"

        Dim adapter As New OleDbDataAdapter(sql, con1)
        Dim dt As New DataTable("EnglishDishes")
        adapter.Fill(dt)
        DataGridViewPrdctMng.DataSource = dt

        Dim sql1 = "SELECT * FROM EnglishDishes"
        Dim adapter1 As New OleDbDataAdapter(sql1, con1)
        Dim cmd1 As New OleDbCommand(sql1, con1)
        con1.Open()
        Dim myreader As OleDbDataReader = cmd1.ExecuteReader
        myreader.Read()

        con1.Close()

        ItemCount = DataGridViewPrdctMng.Rows.Count
        LblItemCount.Text = "Item Count: " & ItemCount

    End Sub

    Private Sub BtnSetMeal_Click(sender As Object, e As EventArgs) Handles BtnSetMeal.Click
        Dim sql As String

        sql = "SELECT * FROM SetMeals"

        Dim adapter As New OleDbDataAdapter(sql, con1)
        Dim dt As New DataTable("SetMeals")
        adapter.Fill(dt)
        DataGridViewPrdctMng.DataSource = dt

        Dim sql1 = "SELECT * FROM SetMeals"
        Dim adapter1 As New OleDbDataAdapter(sql1, con1)
        Dim cmd1 As New OleDbCommand(sql1, con1)
        con1.Open()
        Dim myreader As OleDbDataReader = cmd1.ExecuteReader
        myreader.Read()

        con1.Close()

        ItemCount = DataGridViewPrdctMng.Rows.Count
        LblItemCount.Text = "Item Count: " & ItemCount

    End Sub

End Class