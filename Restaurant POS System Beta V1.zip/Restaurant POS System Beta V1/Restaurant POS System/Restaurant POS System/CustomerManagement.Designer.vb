﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CustomerManagement
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CustomerManagement))
        Me.BtnBack = New System.Windows.Forms.Button()
        Me.PicBox = New System.Windows.Forms.PictureBox()
        Me.BtnTbl1 = New System.Windows.Forms.Button()
        Me.BtnTbl2 = New System.Windows.Forms.Button()
        Me.BtnTbl5 = New System.Windows.Forms.Button()
        Me.BtnTbl6 = New System.Windows.Forms.Button()
        Me.BtnTbl7 = New System.Windows.Forms.Button()
        Me.BtnTbl16 = New System.Windows.Forms.Button()
        Me.BtnTbl10 = New System.Windows.Forms.Button()
        Me.BtnTbl8 = New System.Windows.Forms.Button()
        Me.BtnTbl9 = New System.Windows.Forms.Button()
        Me.BtnTbl14 = New System.Windows.Forms.Button()
        Me.BtnTbl15 = New System.Windows.Forms.Button()
        Me.BtnTbl11 = New System.Windows.Forms.Button()
        Me.BtnTbl12 = New System.Windows.Forms.Button()
        Me.BtnTbl3 = New System.Windows.Forms.Button()
        Me.BtnTbl4 = New System.Windows.Forms.Button()
        Me.TxtBoxOrderDetails = New System.Windows.Forms.TextBox()
        Me.LblFYI = New System.Windows.Forms.Label()
        Me.GrpBoxOrderDetails = New System.Windows.Forms.GroupBox()
        CType(Me.PicBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BtnBack
        '
        Me.BtnBack.Location = New System.Drawing.Point(13, 13)
        Me.BtnBack.Name = "BtnBack"
        Me.BtnBack.Size = New System.Drawing.Size(75, 23)
        Me.BtnBack.TabIndex = 0
        Me.BtnBack.Text = "Back"
        Me.BtnBack.UseVisualStyleBackColor = True
        '
        'PicBox
        '
        Me.PicBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PicBox.Image = Global.Restaurant_POS_System.My.Resources.Resources.BBPOSRestaurantLayout
        Me.PicBox.Location = New System.Drawing.Point(12, 42)
        Me.PicBox.Name = "PicBox"
        Me.PicBox.Size = New System.Drawing.Size(605, 1013)
        Me.PicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicBox.TabIndex = 1
        Me.PicBox.TabStop = False
        '
        'BtnTbl1
        '
        Me.BtnTbl1.Location = New System.Drawing.Point(38, 904)
        Me.BtnTbl1.Name = "BtnTbl1"
        Me.BtnTbl1.Size = New System.Drawing.Size(82, 43)
        Me.BtnTbl1.TabIndex = 2
        Me.BtnTbl1.Text = "Free"
        Me.BtnTbl1.UseVisualStyleBackColor = True
        '
        'BtnTbl2
        '
        Me.BtnTbl2.Location = New System.Drawing.Point(48, 782)
        Me.BtnTbl2.Name = "BtnTbl2"
        Me.BtnTbl2.Size = New System.Drawing.Size(61, 37)
        Me.BtnTbl2.TabIndex = 3
        Me.BtnTbl2.Text = "Free"
        Me.BtnTbl2.UseVisualStyleBackColor = True
        '
        'BtnTbl5
        '
        Me.BtnTbl5.Location = New System.Drawing.Point(22, 327)
        Me.BtnTbl5.Name = "BtnTbl5"
        Me.BtnTbl5.Size = New System.Drawing.Size(44, 49)
        Me.BtnTbl5.TabIndex = 4
        Me.BtnTbl5.Text = "Free"
        Me.BtnTbl5.UseVisualStyleBackColor = True
        '
        'BtnTbl6
        '
        Me.BtnTbl6.Location = New System.Drawing.Point(44, 86)
        Me.BtnTbl6.Name = "BtnTbl6"
        Me.BtnTbl6.Size = New System.Drawing.Size(44, 49)
        Me.BtnTbl6.TabIndex = 5
        Me.BtnTbl6.Text = "Free"
        Me.BtnTbl6.UseVisualStyleBackColor = True
        '
        'BtnTbl7
        '
        Me.BtnTbl7.Location = New System.Drawing.Point(153, 86)
        Me.BtnTbl7.Name = "BtnTbl7"
        Me.BtnTbl7.Size = New System.Drawing.Size(44, 49)
        Me.BtnTbl7.TabIndex = 7
        Me.BtnTbl7.Text = "Free"
        Me.BtnTbl7.UseVisualStyleBackColor = True
        '
        'BtnTbl16
        '
        Me.BtnTbl16.Location = New System.Drawing.Point(142, 327)
        Me.BtnTbl16.Name = "BtnTbl16"
        Me.BtnTbl16.Size = New System.Drawing.Size(55, 49)
        Me.BtnTbl16.TabIndex = 6
        Me.BtnTbl16.Text = "Free"
        Me.BtnTbl16.UseVisualStyleBackColor = True
        '
        'BtnTbl10
        '
        Me.BtnTbl10.Location = New System.Drawing.Point(316, 327)
        Me.BtnTbl10.Name = "BtnTbl10"
        Me.BtnTbl10.Size = New System.Drawing.Size(46, 49)
        Me.BtnTbl10.TabIndex = 8
        Me.BtnTbl10.Text = "Free"
        Me.BtnTbl10.UseVisualStyleBackColor = True
        '
        'BtnTbl8
        '
        Me.BtnTbl8.Location = New System.Drawing.Point(282, 61)
        Me.BtnTbl8.Name = "BtnTbl8"
        Me.BtnTbl8.Size = New System.Drawing.Size(61, 36)
        Me.BtnTbl8.TabIndex = 9
        Me.BtnTbl8.Text = "Free"
        Me.BtnTbl8.UseVisualStyleBackColor = True
        '
        'BtnTbl9
        '
        Me.BtnTbl9.Location = New System.Drawing.Point(296, 175)
        Me.BtnTbl9.Name = "BtnTbl9"
        Me.BtnTbl9.Size = New System.Drawing.Size(57, 43)
        Me.BtnTbl9.TabIndex = 10
        Me.BtnTbl9.Text = "Free"
        Me.BtnTbl9.UseVisualStyleBackColor = True
        '
        'BtnTbl14
        '
        Me.BtnTbl14.Location = New System.Drawing.Point(211, 755)
        Me.BtnTbl14.Name = "BtnTbl14"
        Me.BtnTbl14.Size = New System.Drawing.Size(70, 43)
        Me.BtnTbl14.TabIndex = 11
        Me.BtnTbl14.Text = "Free"
        Me.BtnTbl14.UseVisualStyleBackColor = True
        '
        'BtnTbl15
        '
        Me.BtnTbl15.Location = New System.Drawing.Point(199, 578)
        Me.BtnTbl15.Name = "BtnTbl15"
        Me.BtnTbl15.Size = New System.Drawing.Size(82, 43)
        Me.BtnTbl15.TabIndex = 12
        Me.BtnTbl15.Text = "Free"
        Me.BtnTbl15.UseVisualStyleBackColor = True
        '
        'BtnTbl11
        '
        Me.BtnTbl11.Location = New System.Drawing.Point(367, 578)
        Me.BtnTbl11.Name = "BtnTbl11"
        Me.BtnTbl11.Size = New System.Drawing.Size(82, 43)
        Me.BtnTbl11.TabIndex = 13
        Me.BtnTbl11.Text = "Free"
        Me.BtnTbl11.UseVisualStyleBackColor = True
        '
        'BtnTbl12
        '
        Me.BtnTbl12.Location = New System.Drawing.Point(367, 742)
        Me.BtnTbl12.Name = "BtnTbl12"
        Me.BtnTbl12.Size = New System.Drawing.Size(82, 43)
        Me.BtnTbl12.TabIndex = 14
        Me.BtnTbl12.Text = "Free"
        Me.BtnTbl12.UseVisualStyleBackColor = True
        '
        'BtnTbl3
        '
        Me.BtnTbl3.Location = New System.Drawing.Point(44, 641)
        Me.BtnTbl3.Name = "BtnTbl3"
        Me.BtnTbl3.Size = New System.Drawing.Size(76, 67)
        Me.BtnTbl3.TabIndex = 15
        Me.BtnTbl3.Text = "Free"
        Me.BtnTbl3.UseVisualStyleBackColor = True
        '
        'BtnTbl4
        '
        Me.BtnTbl4.Location = New System.Drawing.Point(44, 497)
        Me.BtnTbl4.Name = "BtnTbl4"
        Me.BtnTbl4.Size = New System.Drawing.Size(76, 67)
        Me.BtnTbl4.TabIndex = 16
        Me.BtnTbl4.Text = "Free"
        Me.BtnTbl4.UseVisualStyleBackColor = True
        '
        'TxtBoxOrderDetails
        '
        Me.TxtBoxOrderDetails.Location = New System.Drawing.Point(650, 101)
        Me.TxtBoxOrderDetails.Multiline = True
        Me.TxtBoxOrderDetails.Name = "TxtBoxOrderDetails"
        Me.TxtBoxOrderDetails.ReadOnly = True
        Me.TxtBoxOrderDetails.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TxtBoxOrderDetails.Size = New System.Drawing.Size(261, 334)
        Me.TxtBoxOrderDetails.TabIndex = 17
        Me.TxtBoxOrderDetails.Text = "Click on a Table to show its Order Details here."
        Me.TxtBoxOrderDetails.WordWrap = False
        '
        'LblFYI
        '
        Me.LblFYI.AutoSize = True
        Me.LblFYI.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblFYI.Location = New System.Drawing.Point(491, 625)
        Me.LblFYI.Name = "LblFYI"
        Me.LblFYI.Size = New System.Drawing.Size(175, 29)
        Me.LblFYI.TabIndex = 18
        Me.LblFYI.Text = "FYI Text Here"
        Me.LblFYI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GrpBoxOrderDetails
        '
        Me.GrpBoxOrderDetails.Location = New System.Drawing.Point(636, 76)
        Me.GrpBoxOrderDetails.Name = "GrpBoxOrderDetails"
        Me.GrpBoxOrderDetails.Size = New System.Drawing.Size(288, 381)
        Me.GrpBoxOrderDetails.TabIndex = 19
        Me.GrpBoxOrderDetails.TabStop = False
        Me.GrpBoxOrderDetails.Text = "Order Details:"
        '
        'CustomerManagement
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(942, 505)
        Me.Controls.Add(Me.LblFYI)
        Me.Controls.Add(Me.TxtBoxOrderDetails)
        Me.Controls.Add(Me.BtnTbl4)
        Me.Controls.Add(Me.BtnTbl3)
        Me.Controls.Add(Me.BtnTbl12)
        Me.Controls.Add(Me.BtnTbl11)
        Me.Controls.Add(Me.BtnTbl15)
        Me.Controls.Add(Me.BtnTbl14)
        Me.Controls.Add(Me.BtnTbl9)
        Me.Controls.Add(Me.BtnTbl8)
        Me.Controls.Add(Me.BtnTbl10)
        Me.Controls.Add(Me.BtnTbl7)
        Me.Controls.Add(Me.BtnTbl16)
        Me.Controls.Add(Me.BtnTbl6)
        Me.Controls.Add(Me.BtnTbl5)
        Me.Controls.Add(Me.BtnTbl2)
        Me.Controls.Add(Me.BtnTbl1)
        Me.Controls.Add(Me.PicBox)
        Me.Controls.Add(Me.BtnBack)
        Me.Controls.Add(Me.GrpBoxOrderDetails)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "CustomerManagement"
        Me.Text = "Customer Management"
        CType(Me.PicBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BtnBack As Button
    Friend WithEvents PicBox As PictureBox
    Friend WithEvents BtnTbl1 As Button
    Friend WithEvents BtnTbl2 As Button
    Friend WithEvents BtnTbl5 As Button
    Friend WithEvents BtnTbl6 As Button
    Friend WithEvents BtnTbl7 As Button
    Friend WithEvents BtnTbl16 As Button
    Friend WithEvents BtnTbl10 As Button
    Friend WithEvents BtnTbl8 As Button
    Friend WithEvents BtnTbl9 As Button
    Friend WithEvents BtnTbl14 As Button
    Friend WithEvents BtnTbl15 As Button
    Friend WithEvents BtnTbl11 As Button
    Friend WithEvents BtnTbl12 As Button
    Friend WithEvents BtnTbl3 As Button
    Friend WithEvents BtnTbl4 As Button
    Friend WithEvents TxtBoxOrderDetails As TextBox
    Friend WithEvents LblFYI As Label
    Friend WithEvents GrpBoxOrderDetails As GroupBox
End Class
