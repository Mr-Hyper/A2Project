﻿Imports System.Data.OleDb
Public Class SalesAccounting
    Protected Overrides ReadOnly Property CreateParams() As CreateParams
        Get
            Dim cp As CreateParams = MyBase.CreateParams
            Const CS_NOCLOSE As Integer = &H200
            cp.ClassStyle = cp.ClassStyle Or CS_NOCLOSE
            Return cp
        End Get
    End Property

    Dim con1 As New OleDbConnection("Provider=Microsoft.Jet.Oledb.4.0;Data Source=Restaurant Transaction Database.mdb")

    Private Sub BtnBack_Click(sender As Object, e As EventArgs) Handles BtnBack.Click

        Me.Close()

    End Sub

    Private Sub SalesAccounting_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim FontSize As Integer

        LblSalesForTodayNo.Text = "£" & FormatNumber(Sales, 2)

        Do While LblSalesForTodayNo.Bounds.IntersectsWith(BtnCrntDayTrans.Bounds)

            Integer.TryParse(LblSalesForTodayNo.Font.Size, FontSize)

            FontSize = FontSize - 1
            LblSalesForTodayNo.Font = New Font(LblSalesForTodayNo.Font.Name, FontSize, LblSalesForTodayNo.Font.Style, LblSalesForTodayNo.Font.Unit)

        Loop

    End Sub

    Private Sub BtnCrntDayTrans_Click(sender As Object, e As EventArgs) Handles BtnCrntDayTrans.Click
        Dim sql As String

        sql = "SELECT * FROM CurrentDayTransactions"

        Dim adapter As New OleDbDataAdapter(sql, con1)
        Dim dt As New DataTable("CurrentDayTransactions")
        adapter.Fill(dt)
        DataGridViewSalesAcc.DataSource = dt

        Dim sql1 = "SELECT * FROM CurrentDayTransactions"
        Dim adapter1 As New OleDbDataAdapter(sql1, con1)
        Dim cmd1 As New OleDbCommand(sql1, con1)
        con1.Open()
        Dim myreader As OleDbDataReader = cmd1.ExecuteReader
        myreader.Read()

        con1.Close()

    End Sub

    Private Sub BtnTransHIstory_Click(sender As Object, e As EventArgs) Handles BtnTransHIstory.Click

        Dim sql As String

        sql = "SELECT * FROM PastTransactions"

        Dim adapter As New OleDbDataAdapter(sql, con1)
        Dim dt As New DataTable("PastTransactions")
        adapter.Fill(dt)
        DataGridViewSalesAcc.DataSource = dt

        Dim sql1 = "SELECT * FROM PastTransactions"
        Dim adapter1 As New OleDbDataAdapter(sql1, con1)
        Dim cmd1 As New OleDbCommand(sql1, con1)
        con1.Open()
        Dim myreader As OleDbDataReader = cmd1.ExecuteReader
        myreader.Read()

        con1.Close()

    End Sub

End Class