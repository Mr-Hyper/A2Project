﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Tables
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Tables))
        Me.BtnBack = New System.Windows.Forms.Button()
        Me.BtnTbl1 = New System.Windows.Forms.Button()
        Me.BtnTbl2 = New System.Windows.Forms.Button()
        Me.BtnTbl3 = New System.Windows.Forms.Button()
        Me.BtnTbl4 = New System.Windows.Forms.Button()
        Me.BtnTbl5 = New System.Windows.Forms.Button()
        Me.BtnTbl6 = New System.Windows.Forms.Button()
        Me.BtnTbl7 = New System.Windows.Forms.Button()
        Me.BtnTbl8 = New System.Windows.Forms.Button()
        Me.BtnTbl9 = New System.Windows.Forms.Button()
        Me.BtnTbl10 = New System.Windows.Forms.Button()
        Me.BtnTbl11 = New System.Windows.Forms.Button()
        Me.BtnTbl12 = New System.Windows.Forms.Button()
        Me.BtnTbl14 = New System.Windows.Forms.Button()
        Me.BtnTbl15 = New System.Windows.Forms.Button()
        Me.BtnTbl16 = New System.Windows.Forms.Button()
        Me.GrpBoxTables = New System.Windows.Forms.GroupBox()
        Me.SuspendLayout()
        '
        'BtnBack
        '
        Me.BtnBack.Location = New System.Drawing.Point(13, 13)
        Me.BtnBack.Name = "BtnBack"
        Me.BtnBack.Size = New System.Drawing.Size(75, 23)
        Me.BtnBack.TabIndex = 0
        Me.BtnBack.Text = "Back"
        Me.BtnBack.UseVisualStyleBackColor = True
        '
        'BtnTbl1
        '
        Me.BtnTbl1.Location = New System.Drawing.Point(13, 61)
        Me.BtnTbl1.Name = "BtnTbl1"
        Me.BtnTbl1.Size = New System.Drawing.Size(75, 65)
        Me.BtnTbl1.TabIndex = 1
        Me.BtnTbl1.Text = "Table 1"
        Me.BtnTbl1.UseVisualStyleBackColor = True
        '
        'BtnTbl2
        '
        Me.BtnTbl2.Location = New System.Drawing.Point(94, 61)
        Me.BtnTbl2.Name = "BtnTbl2"
        Me.BtnTbl2.Size = New System.Drawing.Size(75, 65)
        Me.BtnTbl2.TabIndex = 2
        Me.BtnTbl2.Text = "Table 2"
        Me.BtnTbl2.UseVisualStyleBackColor = True
        '
        'BtnTbl3
        '
        Me.BtnTbl3.Location = New System.Drawing.Point(175, 61)
        Me.BtnTbl3.Name = "BtnTbl3"
        Me.BtnTbl3.Size = New System.Drawing.Size(75, 65)
        Me.BtnTbl3.TabIndex = 3
        Me.BtnTbl3.Text = "Table 3"
        Me.BtnTbl3.UseVisualStyleBackColor = True
        '
        'BtnTbl4
        '
        Me.BtnTbl4.Location = New System.Drawing.Point(256, 61)
        Me.BtnTbl4.Name = "BtnTbl4"
        Me.BtnTbl4.Size = New System.Drawing.Size(75, 65)
        Me.BtnTbl4.TabIndex = 4
        Me.BtnTbl4.Text = "Table 4"
        Me.BtnTbl4.UseVisualStyleBackColor = True
        '
        'BtnTbl5
        '
        Me.BtnTbl5.Location = New System.Drawing.Point(13, 132)
        Me.BtnTbl5.Name = "BtnTbl5"
        Me.BtnTbl5.Size = New System.Drawing.Size(75, 65)
        Me.BtnTbl5.TabIndex = 5
        Me.BtnTbl5.Text = "Table 5"
        Me.BtnTbl5.UseVisualStyleBackColor = True
        '
        'BtnTbl6
        '
        Me.BtnTbl6.Location = New System.Drawing.Point(94, 132)
        Me.BtnTbl6.Name = "BtnTbl6"
        Me.BtnTbl6.Size = New System.Drawing.Size(75, 65)
        Me.BtnTbl6.TabIndex = 6
        Me.BtnTbl6.Text = "Table 6"
        Me.BtnTbl6.UseVisualStyleBackColor = True
        '
        'BtnTbl7
        '
        Me.BtnTbl7.Location = New System.Drawing.Point(175, 132)
        Me.BtnTbl7.Name = "BtnTbl7"
        Me.BtnTbl7.Size = New System.Drawing.Size(75, 65)
        Me.BtnTbl7.TabIndex = 7
        Me.BtnTbl7.Text = "Table 7"
        Me.BtnTbl7.UseVisualStyleBackColor = True
        '
        'BtnTbl8
        '
        Me.BtnTbl8.Location = New System.Drawing.Point(256, 132)
        Me.BtnTbl8.Name = "BtnTbl8"
        Me.BtnTbl8.Size = New System.Drawing.Size(75, 65)
        Me.BtnTbl8.TabIndex = 8
        Me.BtnTbl8.Text = "Table 8"
        Me.BtnTbl8.UseVisualStyleBackColor = True
        '
        'BtnTbl9
        '
        Me.BtnTbl9.Location = New System.Drawing.Point(13, 203)
        Me.BtnTbl9.Name = "BtnTbl9"
        Me.BtnTbl9.Size = New System.Drawing.Size(75, 65)
        Me.BtnTbl9.TabIndex = 9
        Me.BtnTbl9.Text = "Table 9"
        Me.BtnTbl9.UseVisualStyleBackColor = True
        '
        'BtnTbl10
        '
        Me.BtnTbl10.Location = New System.Drawing.Point(94, 203)
        Me.BtnTbl10.Name = "BtnTbl10"
        Me.BtnTbl10.Size = New System.Drawing.Size(75, 65)
        Me.BtnTbl10.TabIndex = 10
        Me.BtnTbl10.Text = "Table 10"
        Me.BtnTbl10.UseVisualStyleBackColor = True
        '
        'BtnTbl11
        '
        Me.BtnTbl11.Location = New System.Drawing.Point(175, 203)
        Me.BtnTbl11.Name = "BtnTbl11"
        Me.BtnTbl11.Size = New System.Drawing.Size(75, 65)
        Me.BtnTbl11.TabIndex = 11
        Me.BtnTbl11.Text = "Table 11"
        Me.BtnTbl11.UseVisualStyleBackColor = True
        '
        'BtnTbl12
        '
        Me.BtnTbl12.Location = New System.Drawing.Point(256, 203)
        Me.BtnTbl12.Name = "BtnTbl12"
        Me.BtnTbl12.Size = New System.Drawing.Size(75, 65)
        Me.BtnTbl12.TabIndex = 12
        Me.BtnTbl12.Text = "Table 12"
        Me.BtnTbl12.UseVisualStyleBackColor = True
        '
        'BtnTbl14
        '
        Me.BtnTbl14.Location = New System.Drawing.Point(54, 274)
        Me.BtnTbl14.Name = "BtnTbl14"
        Me.BtnTbl14.Size = New System.Drawing.Size(75, 65)
        Me.BtnTbl14.TabIndex = 14
        Me.BtnTbl14.Text = "Table 14"
        Me.BtnTbl14.UseVisualStyleBackColor = True
        '
        'BtnTbl15
        '
        Me.BtnTbl15.Location = New System.Drawing.Point(135, 274)
        Me.BtnTbl15.Name = "BtnTbl15"
        Me.BtnTbl15.Size = New System.Drawing.Size(75, 65)
        Me.BtnTbl15.TabIndex = 15
        Me.BtnTbl15.Text = "Table 15"
        Me.BtnTbl15.UseVisualStyleBackColor = True
        '
        'BtnTbl16
        '
        Me.BtnTbl16.Location = New System.Drawing.Point(216, 274)
        Me.BtnTbl16.Name = "BtnTbl16"
        Me.BtnTbl16.Size = New System.Drawing.Size(75, 65)
        Me.BtnTbl16.TabIndex = 16
        Me.BtnTbl16.Text = "Table 16"
        Me.BtnTbl16.UseVisualStyleBackColor = True
        '
        'GrpBoxTables
        '
        Me.GrpBoxTables.Location = New System.Drawing.Point(5, 45)
        Me.GrpBoxTables.Name = "GrpBoxTables"
        Me.GrpBoxTables.Size = New System.Drawing.Size(334, 306)
        Me.GrpBoxTables.TabIndex = 17
        Me.GrpBoxTables.TabStop = False
        Me.GrpBoxTables.Text = "List of available Tables here:"
        '
        'Tables
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(346, 356)
        Me.Controls.Add(Me.BtnTbl16)
        Me.Controls.Add(Me.BtnTbl15)
        Me.Controls.Add(Me.BtnTbl14)
        Me.Controls.Add(Me.BtnTbl12)
        Me.Controls.Add(Me.BtnTbl11)
        Me.Controls.Add(Me.BtnTbl10)
        Me.Controls.Add(Me.BtnTbl9)
        Me.Controls.Add(Me.BtnTbl8)
        Me.Controls.Add(Me.BtnTbl7)
        Me.Controls.Add(Me.BtnTbl6)
        Me.Controls.Add(Me.BtnTbl5)
        Me.Controls.Add(Me.BtnTbl4)
        Me.Controls.Add(Me.BtnTbl3)
        Me.Controls.Add(Me.BtnTbl2)
        Me.Controls.Add(Me.BtnTbl1)
        Me.Controls.Add(Me.BtnBack)
        Me.Controls.Add(Me.GrpBoxTables)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Tables"
        Me.ShowInTaskbar = False
        Me.Text = "Tables"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BtnBack As Button
    Friend WithEvents BtnTbl1 As Button
    Friend WithEvents BtnTbl2 As Button
    Friend WithEvents BtnTbl3 As Button
    Friend WithEvents BtnTbl4 As Button
    Friend WithEvents BtnTbl5 As Button
    Friend WithEvents BtnTbl6 As Button
    Friend WithEvents BtnTbl7 As Button
    Friend WithEvents BtnTbl8 As Button
    Friend WithEvents BtnTbl9 As Button
    Friend WithEvents BtnTbl10 As Button
    Friend WithEvents BtnTbl11 As Button
    Friend WithEvents BtnTbl12 As Button
    Friend WithEvents BtnTbl14 As Button
    Friend WithEvents BtnTbl15 As Button
    Friend WithEvents BtnTbl16 As Button
    Friend WithEvents GrpBoxTables As GroupBox
End Class
