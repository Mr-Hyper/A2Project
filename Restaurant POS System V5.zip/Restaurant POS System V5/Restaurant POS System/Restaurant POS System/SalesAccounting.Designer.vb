﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class SalesAccounting
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SalesAccounting))
        Me.BtnBack = New System.Windows.Forms.Button()
        Me.DataGridViewSalesAcc = New System.Windows.Forms.DataGridView()
        Me.BtnCrntDayTrans = New System.Windows.Forms.Button()
        Me.BtnTransHIstory = New System.Windows.Forms.Button()
        Me.LblSalesForTodayString = New System.Windows.Forms.Label()
        Me.LblSalesForTodayNo = New System.Windows.Forms.Label()
        Me.GrpBoxSalesEarnings = New System.Windows.Forms.GroupBox()
        CType(Me.DataGridViewSalesAcc, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GrpBoxSalesEarnings.SuspendLayout()
        Me.SuspendLayout()
        '
        'BtnBack
        '
        Me.BtnBack.Location = New System.Drawing.Point(13, 13)
        Me.BtnBack.Name = "BtnBack"
        Me.BtnBack.Size = New System.Drawing.Size(75, 23)
        Me.BtnBack.TabIndex = 0
        Me.BtnBack.Text = "Back"
        Me.BtnBack.UseVisualStyleBackColor = True
        '
        'DataGridViewSalesAcc
        '
        Me.DataGridViewSalesAcc.AllowUserToAddRows = False
        Me.DataGridViewSalesAcc.AllowUserToDeleteRows = False
        Me.DataGridViewSalesAcc.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridViewSalesAcc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewSalesAcc.Location = New System.Drawing.Point(13, 181)
        Me.DataGridViewSalesAcc.MultiSelect = False
        Me.DataGridViewSalesAcc.Name = "DataGridViewSalesAcc"
        Me.DataGridViewSalesAcc.ReadOnly = True
        Me.DataGridViewSalesAcc.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridViewSalesAcc.Size = New System.Drawing.Size(775, 257)
        Me.DataGridViewSalesAcc.TabIndex = 52
        '
        'BtnCrntDayTrans
        '
        Me.BtnCrntDayTrans.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCrntDayTrans.Location = New System.Drawing.Point(398, 12)
        Me.BtnCrntDayTrans.Name = "BtnCrntDayTrans"
        Me.BtnCrntDayTrans.Size = New System.Drawing.Size(192, 162)
        Me.BtnCrntDayTrans.TabIndex = 53
        Me.BtnCrntDayTrans.Text = "Current Day Transactions"
        Me.BtnCrntDayTrans.UseVisualStyleBackColor = True
        '
        'BtnTransHIstory
        '
        Me.BtnTransHIstory.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnTransHIstory.Location = New System.Drawing.Point(596, 13)
        Me.BtnTransHIstory.Name = "BtnTransHIstory"
        Me.BtnTransHIstory.Size = New System.Drawing.Size(192, 162)
        Me.BtnTransHIstory.TabIndex = 54
        Me.BtnTransHIstory.Text = "Transaction History"
        Me.BtnTransHIstory.UseVisualStyleBackColor = True
        '
        'LblSalesForTodayString
        '
        Me.LblSalesForTodayString.AutoSize = True
        Me.LblSalesForTodayString.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblSalesForTodayString.Location = New System.Drawing.Point(12, 39)
        Me.LblSalesForTodayString.Name = "LblSalesForTodayString"
        Me.LblSalesForTodayString.Size = New System.Drawing.Size(360, 31)
        Me.LblSalesForTodayString.TabIndex = 55
        Me.LblSalesForTodayString.Text = "Sales Earnings For Today:"
        '
        'LblSalesForTodayNo
        '
        Me.LblSalesForTodayNo.AutoSize = True
        Me.LblSalesForTodayNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblSalesForTodayNo.Location = New System.Drawing.Point(6, 16)
        Me.LblSalesForTodayNo.Name = "LblSalesForTodayNo"
        Me.LblSalesForTodayNo.Size = New System.Drawing.Size(199, 73)
        Me.LblSalesForTodayNo.TabIndex = 56
        Me.LblSalesForTodayNo.Text = "£0.00"
        '
        'GrpBoxSalesEarnings
        '
        Me.GrpBoxSalesEarnings.Controls.Add(Me.LblSalesForTodayNo)
        Me.GrpBoxSalesEarnings.Location = New System.Drawing.Point(12, 73)
        Me.GrpBoxSalesEarnings.Name = "GrpBoxSalesEarnings"
        Me.GrpBoxSalesEarnings.Size = New System.Drawing.Size(380, 101)
        Me.GrpBoxSalesEarnings.TabIndex = 57
        Me.GrpBoxSalesEarnings.TabStop = False
        '
        'SalesAccounting
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.BtnTransHIstory)
        Me.Controls.Add(Me.LblSalesForTodayString)
        Me.Controls.Add(Me.BtnCrntDayTrans)
        Me.Controls.Add(Me.DataGridViewSalesAcc)
        Me.Controls.Add(Me.BtnBack)
        Me.Controls.Add(Me.GrpBoxSalesEarnings)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "SalesAccounting"
        Me.Text = "Sales Accounting"
        CType(Me.DataGridViewSalesAcc, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GrpBoxSalesEarnings.ResumeLayout(False)
        Me.GrpBoxSalesEarnings.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BtnBack As Button
    Friend WithEvents DataGridViewSalesAcc As DataGridView
    Friend WithEvents BtnCrntDayTrans As Button
    Friend WithEvents BtnTransHIstory As Button
    Friend WithEvents LblSalesForTodayString As Label
    Friend WithEvents LblSalesForTodayNo As Label
    Friend WithEvents GrpBoxSalesEarnings As GroupBox
End Class
